/**
 * MarketPulse v2 - Core UI & Interaction Controller
 * Controls theme, currency toggle, Cmd+K search, Ask AI widget, mobile drawer, and shared UI.
 */

(function () {
  'use strict';

  // --- 1. Theme Controller (Light Mode Default) ---
  function initTheme() {
    const savedTheme = localStorage.getItem('mp_theme') || 'light';
    const html = document.documentElement;

    if (savedTheme === 'dark') {
      html.classList.add('dark');
    } else {
      html.classList.remove('dark');
    }

    const toggleBtns = document.querySelectorAll('.theme-toggle-btn');
    toggleBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const isDark = html.classList.toggle('dark');
        localStorage.setItem('mp_theme', isDark ? 'dark' : 'light');
        updateThemeIcons(isDark);
      });
    });

    updateThemeIcons(html.classList.contains('dark'));
  }

  function updateThemeIcons(isDark) {
    document.querySelectorAll('.theme-icon-sun').forEach(el => el.classList.toggle('hidden', !isDark));
    document.querySelectorAll('.theme-icon-moon').forEach(el => el.classList.toggle('hidden', isDark));
  }

  // --- 2. Global Currency Switcher (USD / PKR) ---
  function initCurrencySwitcher() {
    const activeCurr = window.MarketPulseAPI ? window.MarketPulseAPI.getCurrency() : 'USD';
    updateCurrencyButtons(activeCurr);

    document.querySelectorAll('.currency-toggle-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const target = e.currentTarget.getAttribute('data-currency');
        if (target && window.MarketPulseAPI) {
          window.MarketPulseAPI.setCurrency(target);
          updateCurrencyButtons(target);
          updateDOMPrices();
        }
      });
    });

    window.addEventListener('marketpulse:currencyChange', (e) => {
      updateCurrencyButtons(e.detail.currency);
      updateDOMPrices();
    });
  }

  function updateCurrencyButtons(curr) {
    document.querySelectorAll('.currency-toggle-btn').forEach(btn => {
      const isTarget = btn.getAttribute('data-currency') === curr;
      if (isTarget) {
        btn.classList.add('bg-[#F5B700]', 'text-[#0B1220]', 'shadow-sm', 'font-bold');
        btn.classList.remove('text-slate-500', 'hover:text-slate-800');
      } else {
        btn.classList.remove('bg-[#F5B700]', 'text-[#0B1220]', 'shadow-sm', 'font-bold');
        btn.classList.add('text-slate-500', 'hover:text-slate-800');
      }
    });
  }

  function updateDOMPrices() {
    if (!window.MarketPulseAPI) return;
    document.querySelectorAll('[data-price-usd]').forEach(el => {
      const usdVal = parseFloat(el.getAttribute('data-price-usd'));
      if (!isNaN(usdVal)) {
        el.textContent = window.MarketPulseAPI.formatPrice(usdVal);
      }
    });
  }

  // --- 3. Sticky Compact Header on Scroll ---
  function initStickyHeader() {
    const header = document.querySelector('header');
    if (!header) return;

    window.addEventListener('scroll', () => {
      if (window.scrollY > 40) {
        header.classList.add('header-compact');
      } else {
        header.classList.remove('header-compact');
      }
    }, { passive: true });
  }

  // --- 4. Mobile Drawer Navigation ---
  function initMobileDrawer() {
    const openBtn = document.getElementById('mobile-menu-open');
    const closeBtn = document.getElementById('mobile-menu-close');
    const drawer = document.getElementById('mobile-drawer');
    const backdrop = document.getElementById('mobile-drawer-backdrop');

    if (!drawer) return;

    function openDrawer() {
      drawer.classList.remove('translate-x-full');
      if (backdrop) {
        backdrop.classList.remove('opacity-0', 'pointer-events-none');
        backdrop.classList.add('opacity-100');
      }
      document.body.classList.add('overflow-hidden');
    }

    function closeDrawer() {
      drawer.classList.add('translate-x-full');
      if (backdrop) {
        backdrop.classList.remove('opacity-100');
        backdrop.classList.add('opacity-0', 'pointer-events-none');
      }
      document.body.classList.remove('overflow-hidden');
    }

    if (openBtn) openBtn.addEventListener('click', openDrawer);
    if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
    if (backdrop) backdrop.addEventListener('click', closeDrawer);
  }

  // --- 5. Global Search Modal (Cmd/Ctrl + K) ---
  const searchableItems = [
    { type: 'Tool', title: 'DCA Calculator', desc: 'Simulate Dollar Cost Averaging with real historical klines', url: 'dca-calculator.html' },
    { type: 'Tool', title: 'Position Size Calculator', desc: 'Calculate exact risk amount and Risk/Reward ratio', url: 'position-size-calculator.html' },
    { type: 'Tool', title: 'Crypto to PKR Converter', desc: 'Live bidirectional currency converter', url: 'crypto-converter.html' },
    { type: 'Tool', title: 'Gold per Tola Calculator', desc: 'Calculate Pakistani gold tola rates from spot XAU/PAXG', url: 'gold-tola-calculator.html' },
    { type: 'Tool', title: 'Profit & Loss Calculator', desc: 'Compute exact net profit, fees, and ROI %', url: 'profit-loss-calculator.html' },
    { type: 'Market', title: 'Fear & Greed Index', desc: 'Live crypto market sentiment analysis and 30-day history', url: 'fear-greed.html' },
    { type: 'Market', title: 'Top Gainers & Losers', desc: 'Live 24h Binance USDT performance over $5M volume', url: 'gainers-losers.html' },
    { type: 'Market', title: 'Market Heatmap', desc: 'Top 100 coins tile heatmap sized by 24h volume', url: 'heatmap.html' },
    { type: 'Market', title: 'All Markets Screener', desc: 'Complete Binance USDT coins directory with sorting', url: 'markets.html' },
    { type: 'Coin', title: 'Bitcoin (BTC)', desc: 'Live price, TradingView chart, high/low & statistics', url: 'coin.html?symbol=BTCUSDT' },
    { type: 'Coin', title: 'Ethereum (ETH)', desc: 'Live price, TradingView chart, high/low & statistics', url: 'coin.html?symbol=ETHUSDT' },
    { type: 'Coin', title: 'Solana (SOL)', desc: 'Live price, TradingView chart, high/low & statistics', url: 'coin.html?symbol=SOLUSDT' },
    { type: 'Guide', title: 'Crypto Academy', desc: 'Beginner and intermediate guides to blockchain and risk', url: 'academy.html' },
    { type: 'Broker', title: 'Exchanges & Brokers Review', desc: 'Independent ratings, pros/cons, and fees disclosure', url: 'exchanges-brokers.html' },
    { type: 'News', title: 'Crypto Market News', desc: 'Latest breaking institutional and retail headlines', url: 'news.html' }
  ];

  function initSearchModal() {
    const modal = document.getElementById('search-modal');
    const input = document.getElementById('search-input');
    const resultsContainer = document.getElementById('search-results');
    const openBtns = document.querySelectorAll('.search-modal-trigger');
    const closeBtn = document.getElementById('search-modal-close');

    if (!modal || !input) return;

    let selectedIndex = 0;
    let filteredList = [...searchableItems];

    function openModal() {
      modal.classList.remove('hidden');
      document.body.classList.add('overflow-hidden');
      input.value = '';
      filterResults('');
      setTimeout(() => input.focus(), 50);
    }

    function closeModal() {
      modal.classList.add('hidden');
      document.body.classList.remove('overflow-hidden');
    }

    openBtns.forEach(b => b.addEventListener('click', openModal));
    if (closeBtn) closeBtn.addEventListener('click', closeModal);

    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal();
    });

    window.addEventListener('keydown', (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (modal.classList.contains('hidden')) {
          openModal();
        } else {
          closeModal();
        }
      }
      if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
        closeModal();
      }
    });

    input.addEventListener('input', (e) => {
      filterResults(e.target.value);
    });

    input.addEventListener('keydown', (e) => {
      const items = resultsContainer.querySelectorAll('.search-result-row');
      if (!items.length) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        selectedIndex = (selectedIndex + 1) % items.length;
        highlightSelected(items);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        selectedIndex = (selectedIndex - 1 + items.length) % items.length;
        highlightSelected(items);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (filteredList[selectedIndex]) {
          window.location.href = filteredList[selectedIndex].url;
        }
      }
    });

    function filterResults(query) {
      const q = query.toLowerCase().trim();
      filteredList = q === '' 
        ? searchableItems 
        : searchableItems.filter(item => 
            item.title.toLowerCase().includes(q) || 
            item.desc.toLowerCase().includes(q) ||
            item.type.toLowerCase().includes(q)
          );

      selectedIndex = 0;
      renderResults();
    }

    function renderResults() {
      if (!resultsContainer) return;
      if (filteredList.length === 0) {
        resultsContainer.innerHTML = `
          <div class="py-8 text-center text-slate-500">
            <p class="text-sm">No results found for that query.</p>
          </div>
        `;
        return;
      }

      resultsContainer.innerHTML = filteredList.map((item, idx) => `
        <a href="${item.url}" class="search-result-row block p-3 rounded-xl transition flex items-center justify-between group ${idx === selectedIndex ? 'bg-amber-50 dark:bg-slate-800' : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'}">
          <div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">${item.type}</span>
              <span class="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-amber-600">${item.title}</span>
            </div>
            <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">${item.desc}</p>
          </div>
          <span class="text-xs text-slate-400 group-hover:text-slate-600">↵</span>
        </a>
      `).join('');
    }

    function highlightSelected(items) {
      items.forEach((item, idx) => {
        if (idx === selectedIndex) {
          item.classList.add('bg-amber-50', 'dark:bg-slate-800');
          item.scrollIntoView({ block: 'nearest' });
        } else {
          item.classList.remove('bg-amber-50', 'dark:bg-slate-800');
        }
      });
    }
  }

  // --- 6. Floating "Ask AI" Assistant Widget ---
  function initAskAIWidget() {
    const trigger = document.getElementById('ask-ai-trigger');
    const panel = document.getElementById('ask-ai-panel');
    const closeBtn = document.getElementById('ask-ai-close');
    const body = document.getElementById('ask-ai-body');
    const form = document.getElementById('ask-ai-form');
    const input = document.getElementById('ask-ai-input');

    if (!trigger || !panel) return;

    trigger.addEventListener('click', () => {
      panel.classList.toggle('hidden');
      if (!panel.classList.contains('hidden') && input) {
        input.focus();
      }
    });

    if (closeBtn) {
      closeBtn.addEventListener('click', () => panel.classList.add('hidden'));
    }

    // Suggested questions handler
    document.querySelectorAll('.ask-ai-prompt-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const text = btn.innerText.trim();
        handleUserQuery(text);
      });
    });

    if (form && input) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = input.value.trim();
        if (text) {
          handleUserQuery(text);
          input.value = '';
        }
      });
    }

    function handleUserQuery(question) {
      if (!body) return;

      // Add user message bubble
      const userBubble = document.createElement('div');
      userBubble.className = 'flex justify-end mb-3';
      userBubble.innerHTML = `
        <div class="bg-[#F5B700] text-[#0B1220] font-medium text-xs rounded-2xl rounded-tr-none px-3.5 py-2 max-w-[85%]">
          ${escapeHTML(question)}
        </div>
      `;
      body.appendChild(userBubble);
      body.scrollTop = body.scrollHeight;

      // Typing loader
      const loader = document.createElement('div');
      loader.className = 'flex gap-1.5 items-center p-3 rounded-2xl rounded-tl-none bg-slate-100 dark:bg-slate-800 text-slate-500 w-fit mb-3';
      loader.innerHTML = `
        <span class="typing-dot w-2 h-2 rounded-full bg-slate-400"></span>
        <span class="typing-dot w-2 h-2 rounded-full bg-slate-400"></span>
        <span class="typing-dot w-2 h-2 rounded-full bg-slate-400"></span>
      `;
      body.appendChild(loader);
      body.scrollTop = body.scrollHeight;

      // Simulate answer with clear demo label
      setTimeout(() => {
        loader.remove();

        let answer = "Current markets reflect a neutral-to-bullish rotation. Key institutional inflows support spot prices while macroeconomic rates stabilize.";
        if (question.toLowerCase().includes('gold') || question.toLowerCase().includes('tola')) {
          answer = "1 Pakistani Tola (11.664g) is derived from international gold per troy oz times USD/PKR. Check our Gold per Tola Calculator for live rates based on spot bullion.";
        } else if (question.toLowerCase().includes('sentiment') || question.toLowerCase().includes('fear')) {
          answer = "The Fear & Greed Index is currently signaling Greed, indicating heightened retail appetite with caution warranted around major resistance zones.";
        }

        const botBubble = document.createElement('div');
        botBubble.className = 'flex flex-col gap-1 mb-3';
        botBubble.innerHTML = `
          <div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 rounded-2xl rounded-tl-none p-3 max-w-[90%] shadow-sm">
            <p>${answer}</p>
            <div class="mt-2 pt-2 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-[10px] text-slate-400">
              <span class="font-medium text-amber-600 dark:text-amber-400">Demo response</span>
              <span>In production powered by live LLM</span>
            </div>
          </div>
        `;
        body.appendChild(botBubble);
        body.scrollTop = body.scrollHeight;
      }, 700);
    }
  }

  function escapeHTML(str) {
    return str.replace(/[&<>'"]/g, tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  }

  // --- 7. Live Marquee Ticker Tape ---
  async function initMarqueeTicker() {
    const track = document.getElementById('live-ticker-track');
    if (!track || !window.MarketPulseAPI) return;

    try {
      const [coinsRes, ratesRes] = await Promise.all([
        window.MarketPulseAPI.getBinance24h(),
        window.MarketPulseAPI.getCurrencyRates()
      ]);

      const coins = coinsRes.data.slice(0, 8);
      const rates = ratesRes.rates;

      const items = [
        ...coins.map(c => ({
          name: c.code,
          price: window.MarketPulseAPI.formatPrice(c.price),
          change: c.change24h
        })),
        {
          name: 'USD/PKR',
          price: '₨ ' + rates.pkr.toFixed(2),
          change: 0.12
        },
        {
          name: 'EUR/USD',
          price: '$' + (1 / rates.eur).toFixed(4),
          change: -0.08
        },
        {
          name: 'Spot Gold',
          price: '$' + (coins.find(c => c.code === 'PAXG')?.price || 2685.50).toFixed(1),
          change: 0.45
        },
        {
          name: 'Crude Oil',
          price: '$72.40',
          change: -0.85
        }
      ];

      function buildHTML(list) {
        return list.map(item => {
          const isUp = item.change >= 0;
          const arrow = isUp ? '▲' : '▼';
          const color = isUp ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400';
          return `
            <div class="inline-flex items-center gap-2 px-4 py-1.5 border-r border-slate-200 dark:border-slate-800 text-xs whitespace-nowrap">
              <span class="font-bold text-slate-900 dark:text-white">${item.name}</span>
              <span class="font-mono text-slate-700 dark:text-slate-300">${item.price}</span>
              <span class="font-semibold ${color} flex items-center gap-0.5">
                <span class="text-[9px]">${arrow}</span>
                <span>${isUp ? '+' : ''}${item.change.toFixed(2)}%</span>
              </span>
            </div>
          `;
        }).join('');
      }

      // Double the items for endless loop
      track.innerHTML = buildHTML(items) + buildHTML(items);
    } catch (e) {
      console.warn('Ticker hydration error:', e);
    }
  }

  // --- 8. Scroll Reveal Animations ---
  function initScrollReveal() {
    const reveals = document.querySelectorAll('.reveal-on-scroll');
    if (!reveals.length) return;

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-revealed');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    reveals.forEach(el => observer.observe(el));
  }

  // --- 9. Article Reading Progress Bar ---
  function initReadingProgressBar() {
    const bar = document.querySelector('.reading-progress-bar');
    if (!bar) return;

    window.addEventListener('scroll', () => {
      const total = document.documentElement.scrollHeight - window.innerHeight;
      const progress = total > 0 ? (window.scrollY / total) * 100 : 0;
      bar.style.width = Math.min(Math.max(progress, 0), 100) + '%';
    }, { passive: true });
  }

  // --- 10. Sparkline Inline SVG Generator ---
  window.generateSparklineSVG = function (points, isGain, width = 90, height = 28) {
    if (!points || points.length < 2) {
      // Default dummy trend
      points = isGain ? [10, 12, 11, 15, 14, 18, 22] : [22, 19, 20, 16, 17, 13, 10];
    }
    const min = Math.min(...points);
    const max = Math.max(...points);
    const range = max - min || 1;

    const coords = points.map((p, i) => {
      const x = (i / (points.length - 1)) * (width - 4) + 2;
      const y = height - 4 - ((p - min) / range) * (height - 8);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });

    const strokeColor = isGain ? '#0E9F6E' : '#E11D48';
    return `
      <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" class="overflow-visible inline-block">
        <polyline fill="none" stroke="${strokeColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" points="${coords.join(' ')}" class="sparkline-path draw" />
      </svg>
    `;
  };

  // --- 11. Newsletter Form Handler ---
  function initNewsletterForm() {
    const form = document.getElementById('newsletter-form');
    const successMsg = document.getElementById('newsletter-success');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      form.classList.add('hidden');
      if (successMsg) successMsg.classList.remove('hidden');
    });
  }

  // Bootstrap all UI features
  document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initCurrencySwitcher();
    initStickyHeader();
    initMobileDrawer();
    initSearchModal();
    initAskAIWidget();
    initMarqueeTicker();
    initScrollReveal();
    initReadingProgressBar();
    initNewsletterForm();
  });

})();
